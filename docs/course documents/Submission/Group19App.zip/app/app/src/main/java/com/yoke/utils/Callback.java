package com.yoke.utils;

/**
 * An interface for async callbacks
 */
public interface Callback {
    void call();
}
