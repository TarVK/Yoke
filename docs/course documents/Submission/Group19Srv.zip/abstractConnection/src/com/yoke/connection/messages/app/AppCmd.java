package com.yoke.connection.messages.app;

import com.yoke.connection.Message;

/**
 * An abstract class representing internal app commands
 */
public abstract class AppCmd extends Message {
    // Serialization ID
    private static final long serialVersionUID = 4298204345886298203L;
}
