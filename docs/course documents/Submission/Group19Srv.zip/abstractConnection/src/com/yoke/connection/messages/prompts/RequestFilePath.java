package com.yoke.connection.messages.prompts;

import com.yoke.connection.Message;

/**
 * A message representing the app requesting a file path from the user
 */
public class RequestFilePath extends Message {
    // Serialization ID
    private static final long serialVersionUID = 6460178411962723092L;
    
}
