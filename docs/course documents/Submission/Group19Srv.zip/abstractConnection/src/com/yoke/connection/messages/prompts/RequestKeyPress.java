package com.yoke.connection.messages.prompts;

import com.yoke.connection.Message;

/**
 * A message representing the app requesting a key press ID 
 */
public class RequestKeyPress extends Message {
    // Serialization ID
    private static final long serialVersionUID = 1L;

}
